<?php

class IndexModel extends Model
{
	const OFFSET = 0;
	const NUMBER = 4;

	public function __construct()
	{
		parent:: __construct();
	}
}
