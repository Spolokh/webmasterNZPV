
	<h2 align="center"><?=$query->name ?></h2>

    <p align="center">
		<img width="400" src="/img/<?=($query->icon ? $query->icon : 'default.png') ?>" alt=""/>
	</p>


	<ul align="center">
		<li><?=$query->mail ?></li>
		<li><?=$query->phone ?></li>
	</ul>

